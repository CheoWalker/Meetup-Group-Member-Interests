﻿window.Byutv = window.Byutv || {};
Byutv.elements = Byutv.elements || {};

Byutv.Jsonp = Byutv.elements.Jsonp = Polymer({
	is: "byutv-jsonp",
	behaviors: [Byutv.behaviors.Jsonp]
});